监控结果同时输出到屏幕和文件
./csw.sh | tee a.log
