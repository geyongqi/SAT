#/bin/bash
gcc -I /usr/src/linux-2.6.34.14/include cswmonitor.c -o cswmonitor
