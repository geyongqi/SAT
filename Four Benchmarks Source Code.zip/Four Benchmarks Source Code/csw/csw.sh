#!/bin/sh
while :
do
printf "\n\n";
date=$(date +%Y%m%d%H:%M:%S)
printf "============================="
echo $date
PID=`ps -A | grep LINPACK_BENCH | awk '{print $1}'` 
PID2=`ps -A | grep memory_test | awk '{print $1}'` 
PID3=`ps -A | grep Whetstone | awk '{print $1}'` 
PID4=`ps -A | grep mxm | awk '{print $1}'` 
PID5=`ps -A | grep csw.sh | awk '{print $1}'` 


printf "*****************LINPACK_BENCH Monitor*********************************\n"
/home/gyq/papertest/SelectDir/csw/cswmonitor  -p $PID -q -m "0" 

printf "*****************memory_test Monitor************************************\n"

/home/gyq/papertest/SelectDir/csw/cswmonitor  -p $PID2 -q -m "0" 

printf "******************Whetstone Monitor*************************************\n"

/home/gyq/papertest/SelectDir/csw/cswmonitor  -p $PID3 -q -m "0" 

printf "******************mxm Monitor*************************************\n"

/home/gyq/papertest/SelectDir/csw/cswmonitor  -p $PID4 -q -m "0" 

printf "*******************cswmonitor Monitor***********************************\n"

/home/gyq/papertest/SelectDir/csw/cswmonitor  -p $PID5 -q -m "0" 

sleep 100 

done

