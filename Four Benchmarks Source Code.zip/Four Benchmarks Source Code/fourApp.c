#include<stdio.h>
#include<sched.h>
#include<stdlib.h>
#include<string.h>
#include<errno.h>

void sched_set_threshold(pid_t pid, unsigned int rt_threshold)
{
	syscall(338, pid, rt_threshold);	
}
void sched_get_threshold(pid_t pid, unsigned int *rt_threshold)
{
	syscall(337, pid, rt_threshold);
}

int main()
{
	pid_t ppid, cpid1, cpid2, cpid3,cpid4,cpid5;
	struct sched_param  pparam, cparam1, cparam2, cparam3, cparam4,cparam5;
	unsigned int p_rt_threshold, c1_rt_threshold, c2_rt_threshold, c3_rt_threshold, c4_rt_threshold,c5_rt_threshold;
	
	pparam.sched_priority = 71;          // prio = 99 - sched_priority =28 
	p_rt_threshold = 28;
	ppid = getpid();
	
	sched_setscheduler(ppid, SCHED_FIFO, &pparam);
	sched_set_threshold(ppid, p_rt_threshold);
	cpid1 = fork();
	switch(cpid1)
	{
	  case -1: 
	  		perror("fork() failed! \n");
	  		break;
	  case 0: 
	  		cparam1.sched_priority = 46;     //prio = 99 - sched_priority = 53 
	  		c1_rt_threshold = 53;
	  		cpid1 = getpid();
	  		sched_setscheduler(cpid1, SCHED_FIFO, &cparam1);
	  		sched_set_threshold(cpid1, c1_rt_threshold);
	  		if(execlp("./LINPACK_BENCH/LINPACK_BENCH", "./LINPACK_BENCH/LINPACK_BENCH",NULL,(char *)0) < 0)
	  			perror("LINPACK_BENCH failed! \n");
			printf("LINPACK_BENCH over!\n");
	  		break;
	  default:
	  		cpid2 = fork();
	  		if(cpid2 == -1)
	  		{
	  				perror("fork() failed! \n");
	  		}
	  		else if(cpid2 == 0)
	  		{
	  				cparam2.sched_priority = 29;     //prio = 99 - sched_priority =70 
	  				c2_rt_threshold = 70;
	  				sched_setscheduler(getpid(), SCHED_FIFO, &cparam2);
	  				sched_set_threshold(getpid(), c2_rt_threshold);
	  				if(execlp("./memory_test/memory_test", "./memory_test/memory_test",NULL,(char *)0)<0)
	  					perror("memory_test failed! \n");
				  	printf("memory_test over!\n");
	  		}
	  		else
	  		{
                    cpid3 = fork();
					if(cpid3 == -1)
					{
					   perror("cpid3 fork() error!\n");
					}
					else if(cpid3 == 0)
					{
					    cparam3.sched_priority = 37;     //prio = 99 - sched_priority = 62
                        c3_rt_threshold = 62;
                        sched_setscheduler(getpid(), SCHED_FIFO, &cparam3);
                        sched_set_threshold(getpid(), c3_rt_threshold);
                        if(execlp("./WHETSTONE/Whetstone", "./WHETSTONE/Whetstone", NULL,(char *)0)<0)
                            perror("Whetstone failed! \n");
				  	    printf("Whetstone over!\n");
					}
					else
					{
                        cpid4 = fork();
                        if(cpid4 == -1)
                        {
                            perror("cpid4 fork() error!\n");
                        }
                        else if(cpid4 ==0)
                        {
					      cparam4.sched_priority = 54;     //prio = 99 - sched_priority =45 
                          c4_rt_threshold = 45;
                          sched_setscheduler(getpid(), SCHED_FIFO, &cparam4); 
                          sched_set_threshold(getpid(), c4_rt_threshold);
	  			          if(execlp("./MXM/mxm", "./MXM/mxm", NULL,(char *)0)<0)
              			  perror("mxm failure! \n");

				    	}
                        else{
					 cpid5 = fork();
                        if(cpid5 == -1)
                        {
                            perror("cpid5 fork() error!\n");
                        }
                        else if(cpid5 ==0)
                        {
					      cparam5.sched_priority = 71;     //prio = 99 - sched_priority =28 
                          c5_rt_threshold = 28;
                          sched_setscheduler(getpid(), SCHED_FIFO, &cparam4); 
                          sched_set_threshold(getpid(), c5_rt_threshold);
	  			          if(execlp("/bin/sh","sh","-c","./csw/csw.sh > /home/gyq/papertest/SelectDir/a.log", (char *)0) < 0)
              			  perror("stap failure! \n");

				    	}
                        else{
								
			}			
			}
	  		}
	  		break;
	 }
    }
}
