#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QtGui>
#include <dirent.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <QDialog>

/* Global Var to indicate actual number of tasks */
int taskNum;

/* Self-defined System Calls */
void MainWindow::sched_set_threshold(pid_t pid, unsigned int rt_threshold)
{
    syscall(338, pid, rt_threshold);
}
void MainWindow::sched_get_threshold(pid_t pid, unsigned int *rt_threshold)
{
    syscall(337, pid, rt_threshold);
}

MainWindow::MainWindow(QWidget *parent) :
        QMainWindow(parent),
        ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    /* Set Current Process as RT Process */
    pparam.sched_priority = 24;                 // prio = 99 - sched_priority = 75
    p_rt_threshold = 70;
    ppid = getpid();
    sched_setscheduler(ppid, SCHED_RR, &pparam);
    sched_set_threshold(ppid, p_rt_threshold);

    taskNum = 0;
    taskFlag = 0;
    monitorFlag = 0;

    /* Set taskList's Font */
    QFont f( "Arial", 10, QFont::Bold);
    ui->taskList->setFont(f);
    ui->taskThreshold->setFont(f);
    ui->taskRunningEdit->setFont(f);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::changeEvent(QEvent *e)
{
    QMainWindow::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}

/* ADD TASK Button's Action */
void MainWindow::on_addTaskBtn_clicked()
{
    if(taskNum == 0)
    {
        ui->taskList->append(QString(" Name Period Priority WCET DeadLine"));
        ui->taskList->append(QString("--------------------------------------------------------------"));
    }
    if(taskNum >= MAXTASKNUM)
    {
        QMessageBox::warning(this, QString("Warning"), QString("Too much tasks!"), QMessageBox::Cancel | QMessageBox::Close);
        ui->taskList->clear();
        taskNum = 0;
    }
    else
    {
        taskName[taskNum] = ui->taskNameEdit->text();
        taskPeriod[taskNum] = ui->periodEdit->text().toInt();
        taskPriority[taskNum] = ui->priorityEdit->text().toInt();
        //taskWcrt[taskNum] = ui->wcrtEdit->text().toInt();
        taskWcet[taskNum] = ui->wcetEdit->text().toInt();
        taskDeadLine[taskNum] = ui->deadLineEdit->text().toInt();
        QString temp = taskName[taskNum]+QString("          ")+QString::number(taskPeriod[taskNum])+QString("          ")+QString::number(taskPriority[taskNum])+QString("        ")+QString::number(taskWcet[taskNum])+QString("         ")+QString::number(taskDeadLine[taskNum]);
        ui->taskList->append(temp);
        taskNum++;
    }
}

/* Compute Threshold Button's Action */
void MainWindow::on_compThrBtn_clicked()
{
    int i;

    MainEntry(taskName, taskWcet, taskPeriod, taskDeadLine, taskPriority, taskThreshold, &taskFlag);
    if(taskFlag == 1)
    {
        for(i=0;i<taskNum;i++)
            ui->taskThreshold->append(taskName[i]+QString(":      ")+QString::number(taskThreshold[i],10));
    }
    else
        ui->taskThreshold->append(QString("Warning: Cann't Scheduling!"));
}
/* The Entry to Call Threshold Computing Routine */
int MainEntry(QString TaskName[TASKNUM],int C[TASKNUM],int T[TASKNUM], int D[TASKNUM], int Prio[TASKNUM], int taskThreshold[TASKNUM], int *taskFlag)
{
    int flag = 0;
    flag = SortTask(TaskName,C,T,D,Prio,taskThreshold,taskFlag);
    return flag;
}
/* Sort Tasks via priority */
int SortTask(QString TaskName[TASKNUM],int C[TASKNUM],int T[TASKNUM], int D[TASKNUM], int Prio[TASKNUM], int taskThreshold[TASKNUM], int *taskFlag)
{
    int i, j;
    int prio, c, t, d;
    int flag  = 0;
    QString s;
    for(i = 0;i < taskNum-1;i++)
        for(j = 0;j<taskNum-i-1;j++)
            if(Prio[j] < Prio[j+1])
            {
        s = TaskName[j];
        prio = Prio[j];
        c = C[j];
        t = T[j];
        d = D[j];
        //
        TaskName[j] = TaskName[j+1];
        Prio[j] = Prio[j+1];
        C[j] = C[j+1];
        T[j] = T[j+1];
        D[j] = D[j+1];
        //
        TaskName[j+1] = s;
        Prio[j+1] = prio;
        C[j+1] = c;
        T[j+1] = t;
        D[j+1] = d;
    }
    for(i=0;i < taskNum;i++)
        taskThreshold[i] = Prio[i];
    //
    *taskFlag = Compute_Threshold(TaskName,C,T,D,Prio,taskThreshold);

    return flag;
}
/* Compute Threshold */
int Compute_Threshold(QString TaskName[TASKNUM], int C[TASKNUM], int T[TASKNUM], int D[TASKNUM], int Prio[TASKNUM], int Thr[TASKNUM])
{
    int i;
    int  R[TASKNUM];
    for(i=0;i<taskNum;i++)
    {
        Thr[i] = Prio[i];
        R[i] = preSchedWithThres(C,T,D,Prio,Thr,i);
        while(R[i] > D[i])
        {
            Thr[i]--;
            if(Thr[i] < 0)
                return 0;
            R[i] = preSchedWithThres(C,T,D,Prio,Thr,i);
        }
    }
    return 1;
}

/* Preemptive Schedule */
int * preSched(int C[TASKNUM], int T[TASKNUM], int D[TASKNUM], int Prio[TASKNUM])
{
    double w[TASKNUM][POLLNUM+1];
    static  int wcrt[TASKNUM];
    int i,j;
    int m;
    for(i=0;i<taskNum;i++)
        for(j=1;j<=POLLNUM;j++)
            w[i][j] = Level_i_Busy_Period(i,j,C,Prio,T);

    for(i=0;i<taskNum;i++)
    {
        m = Optimal(i, w, T);
        wcrt[i] = WCRT(i, m, w, T);
    }
    return wcrt;  
}
/* Non-Preemptive Schedule */
int * non_proSched(int C[TASKNUM], int T[TASKNUM], int Prio[TASKNUM])
{
    int B[TASKNUM];
    double w[TASKNUM][POLLNUM+1];    //
    static int wcrt[TASKNUM];
    int i,j,m;
    for(i=0;i<taskNum;i++)
        B[i] = Block_Time(i, C, Prio);

    for(i=0;i<taskNum;i++)
        for(j=1;j<=POLLNUM;j++)
            w[i][j] = Level_i_Busy_Period_noPre(i,j,C,Prio,T,B);

    for(i=0;i<taskNum;i++)
    {
        m = Optimal(i, w, T);
        wcrt[i] = WCRT(i, m, w, T);
    }
    return wcrt;
}
/* Preemptive Schedule With Threshold */
int preSchedWithThres(int C[TASKNUM],int T[TASKNUM], int D[TASKNUM], int Prio[TASKNUM], int Thr[TASKNUM], int index)
{
    int B[TASKNUM];
    double w[TASKNUM][POLLNUM+1];
    double s[TASKNUM][POLLNUM+1];
    int wcrt[TASKNUM];
    int i,j,m;
    for(i=0;i<taskNum;i++)
        B[i] = Block_Time_Thr(i, C, Prio, Thr);

    for(i=0;i<taskNum;i++)
        for(j=1;j<=POLLNUM;j++)
            s[i][j] = Level_i_Busy_Period_S(i,j,C,Prio,T,B,Thr);

    for(i=0;i<taskNum;i++)
        for(j=1;j<=POLLNUM;j++)
            w[i][j] = Level_i_Busy_Period_Thr(i,j,C,Prio,T,s,Thr);

    for(i=0;i<taskNum;i++)
    {
        m = Optimal(i, w, T);
        wcrt[i] = WCRT(i, m, w, T);
    }
    return wcrt[index];
}
/* Called by Menu */
int * rePreSchedWithThres(int C[TASKNUM],int T[TASKNUM], int Prio[TASKNUM], int Thr[TASKNUM])
{
    int B[TASKNUM];
    double w[TASKNUM][POLLNUM+1];
    double s[TASKNUM][POLLNUM+1];
    static int wcrt[TASKNUM];
    int i,j,m;
    for(i=0;i<taskNum;i++)
        B[i] = Block_Time_Thr(i, C, Prio, Thr);

    for(i=0;i<taskNum;i++)
        for(j=1;j<=POLLNUM;j++)
            s[i][j] = Level_i_Busy_Period_S(i,j,C,Prio,T,B,Thr);

    for(i=0;i<taskNum;i++)
        for(j=1;j<=POLLNUM;j++)
            w[i][j] = Level_i_Busy_Period_Thr(i,j,C,Prio,T,s,Thr);

    for(i=0;i<taskNum;i++)
    {
        m = Optimal(i, w, T);
        wcrt[i] = WCRT(i, m, w, T);
    }
    return wcrt;
}
/* Level_i_Busy_Period_Thr */
double Level_i_Busy_Period_Thr(int index, int q, int C[TASKNUM], int Prio[TASKNUM], int T[TASKNUM], double (*S)[POLLNUM+1], int Thr[TASKNUM])
{
    double w0 = S[index][q] + C[index];
    double w1 = 0;
    w1 = S[index][q] + C[index] + Sigma_Thr(index,q,w0,C,Prio,T,S,Thr);
    while( abs(w1 - w0) >= 1e-10)
    {
        w0 = w1;
        w1 = S[index][q] + C[index] + Sigma_Thr(index,q,w0,C,Prio,T,S,Thr);
    }
    return w0;
}
/* Sigma_Thr */
double Sigma_Thr(int index, int q,double w, int C[TASKNUM], int Prio[TASKNUM], int T[TASKNUM], double (*S)[POLLNUM+1], int Thr[TASKNUM])
{
    int i;
    double sum = 0;
    for(i=0;i<taskNum;i++)
        if(i!=index)
            if(Prio[i] < Thr[index])
                sum +=  (ceil(w/T[i])-(floor(S[index][q]/T[i])+1))*C[i];
    return sum;
}
/* Sigma_S */
double Sigma_S(int index, int q,double w, int C[TASKNUM], int Prio[TASKNUM], int T[TASKNUM],int Thr[TASKNUM])
{
    int i;
    double sum = 0;
    for(i=0;i<taskNum;i++)
        if(i!=index)
            if(Prio[i] < Prio[index])
                sum +=  (floor(w/T[i])+1)*C[i];
    return sum;
}
/*  */
double Level_i_Busy_Period_S(int index, int q, int C[TASKNUM], int Prio[TASKNUM], int T[TASKNUM], int B[TASKNUM],int Thr[TASKNUM])
{
    double w0 = B[index] + (q-1)*C[index];
    double w1 = 0;
    w1 = B[index] + (q-1)*C[index] + Sigma_S(index,q,w0,C,Prio,T,Thr);
    while( abs(w1 - w0) >= 1e-10)
    {
        w0 = w1;
        w1 = B[index] + (q-1)*C[index] + Sigma_S(index,q,w0,C,Prio,T,Thr);
    }
    return w0;
}
/*  */
int Block_Time_Thr(int index, int C[TASKNUM], int Prio[TASKNUM], int Thr[TASKNUM])
{
    int i;
    int max_block_time = 0;
    for(i=0;i<taskNum;i++)
        if(i!=index)
            if((Prio[i] > Prio[index])&&(Thr[i] <= Prio[index])&&(C[i] > max_block_time))
                max_block_time = C[i];
    return max_block_time;
}

/* Block Time */
int Block_Time(int index, int C[TASKNUM], int Prio[TASKNUM])
{
    int i;
    int max_block_time = 0;
    for(i=0;i<taskNum;i++)
        if((Prio[i] > Prio[index])&&(C[i] > max_block_time))
            max_block_time = C[i];
    return max_block_time;
}
/* Level_i_Busy_Period_noPre */
int Level_i_Busy_Period_noPre(int index, int q, int C[TASKNUM], int Prio[TASKNUM], int T[TASKNUM], int B[TASKNUM])
{
    double w0 = B[index] + q*C[index];
    double w1 = 0;
    w1 = B[index] + q*C[index] + Sigma_noPre(index,q,w0,C,Prio,T);
    while( abs(w1 - w0) >= 0.01)
    {
        w0 = w1;
        w1 = B[index] + q*C[index] + Sigma_noPre(index,q,w0,C,Prio,T);
    }
    return w0;
}
/* Sigma */
double Sigma_noPre(int index, int q,double w, int C[TASKNUM], int Prio[TASKNUM], int T[TASKNUM])
{
    int i;
    double sum = 0;
    for(i=0;i<taskNum;i++)
        if(Prio[i] < Prio[index])
            sum +=  (floor((w-C[index])/T[i])+1)*C[i];
    return sum;
}
/* WCRT */
int WCRT(int index, int m, double (*W)[POLLNUM+1], int T[TASKNUM])
{
    int i;
    int max = 0;
    int temp;
    for(i=1;i<=m;i++)
    {
        temp = W[index][i]-(i-1)*T[index];
        if(temp > max)
            max = temp;
    }
    return max;
}
/* WCRT */
int Level_i_Busy_Period(int index, int q, int C[TASKNUM], int Prio[TASKNUM], int T[TASKNUM])
{
    double w0 = q*C[index];
    double w1 = 0;
    w1 = q*C[index] + Sigma(index,q,w0,C,Prio,T);
    while( abs(w1 - w0) >= 0.01)
    {
        w0 = w1;
        w1 = q*C[index] + Sigma(index,q,w0,C,Prio,T);
    }
    return w0;
}
/* Sigma */
double Sigma(int index, int q,double w, int C[TASKNUM], int Prio[TASKNUM], int T[TASKNUM])
{
    int i;
    double sum = 0;
    for(i=0;i<taskNum;i++)
        if(Prio[i] < Prio[index])
            sum +=  ceil(w/T[i])*C[i];
    return sum;
}
/*  */
int Optimal(int index, double (*W)[POLLNUM+1], int T[TASKNUM])
{
    int i;
    for(i=1;i<=POLLNUM;i++)
        if(W[index][i] <= i*T[index])
            return i;
}

void MainWindow::on_actionVersion_triggered()
{
    QMessageBox::information(this, tr("Version"),tr("Version 1.0"), QMessageBox::Ok|QMessageBox::Close);
}

void MainWindow::on_actionCreator_triggered()
{
    QMessageBox::information(this, tr("Creator"),tr("Chunxin Yang @ NPU"), QMessageBox::Ok|QMessageBox::Close);
}

void MainWindow::on_taskStartBtn_clicked()
{
    DIR *dir;
    QString monitorTaskName;
    dir = opendir("/proc");
    monitorTaskName = ui->monitorTaskEdit->text();

    if (!dir)
    {
        QMessageBox::warning(this, QString("Warning"), QString("Cannot open /proc!"), QMessageBox::Cancel | QMessageBox::Close);
        return ;
    }
    ui->taskRunningStatics->clear();
    QString fileName = printTaskInfo(monitorTaskName, dir);
    //
    if(fileName == QString(""))
        QMessageBox::warning(this, QString("Warning"), QString("filePath == NULL!"), QMessageBox::Cancel | QMessageBox::Close);

    QFile f(fileName);
    if(!f.open(QIODevice::ReadOnly))
    {
        QMessageBox::warning(this, QString("Warning"), QString("Cannot open file!"), QMessageBox::Cancel | QMessageBox::Close);
    }
    QTextStream sched(&f);
    ui->taskRunningStatics->append(sched.readAll());
    f.close();
    closedir(dir);
    //
}
QString MainWindow::printTaskInfo(QString TaskName, DIR *dir)
{
    struct dirent *next;
    char *taskName;
    QByteArray ba = TaskName.toLatin1();
    taskName = ba.data();

    while ((next = readdir(dir)) != NULL)
    {
        FILE *status;
        char filename[50];
        char buffer[50];
        char name[50];
        char filePath[50];

        if (strcmp(next->d_name, "..") == 0)
            continue;
        if (!isdigit(*next->d_name))
            continue;
        sprintf(filename, "/proc/%s/status", next->d_name);
        if (! (status = fopen(filename, "r")) )
        {
            continue;
        }
        if (fgets(buffer, 49, status) == NULL)
        {
            fclose(status);
            continue;
        }
        fclose(status);
        sscanf(buffer, "%*s %s", name);
        if (strcmp(name, taskName) == 0)
        {
            sprintf(filePath, "/proc/%s/sched", next->d_name);
            QString filePathStr = QString(filePath);
            return filePathStr;
        }
    }
  return QString("");
}

void MainWindow::on_taskRunningBtn_clicked()
{
    ui->taskRunningEdit->clear();
    pid_t cpid;
    int fd;
    int i;
    cpid = fork();
    if(cpid == -1)
        QMessageBox::warning(this, QString("Warning"), QString("Fork Error!"), QMessageBox::Cancel | QMessageBox::Close);
    else if(cpid ==0)
    {
        fd = open("/tmp/ps.txt",(O_RDWR | O_CREAT), 0644);
        dup2(fd,1);
        if(execlp("ps","ps","-eo","pid,ppid,class,rtprio,priority,pcpu,pmem,stat,comm",(char *)NULL))
            QMessageBox::warning(this, QString("Warning"), QString("Execlp Error!"), QMessageBox::Cancel | QMessageBox::Close);
    }
    else
    {
        waitpid(cpid,NULL,0);
        QString psName = QString("/tmp/ps.txt");
        QFile ps(psName);
        if(!ps.open(QIODevice::ReadOnly))
        {
            QMessageBox::warning(this, QString("Warning"), QString("Cannot open file!"), QMessageBox::Cancel | QMessageBox::Close);
        }
        QTextStream psTs(&ps);
        ui->taskRunningEdit->append(QString("PID    PPID   CLASS   RTPRIO   PRI   CPU   MEM   STAT   COMMAND"));
        ui->taskRunningEdit->append(QString("------------------------------------------------------------------------------------------------------------"));
        psTs.readLine();
        while(!psTs.atEnd())
        {
            QString temp;
            QString tempStr;
            QStringList  qsList = psTs.readLine().trimmed().split(QRegExp("\\s+"));
            if(qsList.size()<9 || qsList.at(3) == "-")
                continue;
            for(i=0;i<qsList.size();i++)
            {
                switch(i)
                {
                case 0:
                    tempStr = qsList.at(i+1);
                    if(tempStr.toInt()>=1000)
                        temp +=qsList.at(i)+"   ";
                    else
                        temp +=qsList.at(i)+"           ";
                    break;
                case 1: temp +=qsList.at(i)+"       ";
                    break;
                case 2: temp +=qsList.at(i)+"          ";
                    break;
                case 3: temp +=qsList.at(i)+"            ";
                    break;
                case 4:
                    tempStr = qsList.at(i);
                    tempStr = QString::number(tempStr.toInt()+100);
                    temp +=tempStr+"     ";
                    break;
                case 5: temp +=qsList.at(i)+"       ";
                    break;
                case 6: temp +=qsList.at(i)+"       ";
                    break;
                case 7:
                    tempStr = qsList.at(i+1);
                    if(tempStr.size()>=8)
                        temp +=qsList.at(i)+"   ";
                    else
                        temp +=qsList.at(i)+"       ";
                    break;
                case 8: temp +=qsList.at(i);
                    break;
                default: break;
                }
            }
            ui->taskRunningEdit->append(temp);
        }
        ps.close();
    }
}

void MainWindow::on_actionNonPreemWcrt_triggered()
{
    int * nonPreemWcrt, i;
    QString disPlay;
    QDialog * nonPreemWcrtDlg = new QDialog(this);
    QHBoxLayout * layout = new QHBoxLayout(nonPreemWcrtDlg);
    layout->setMargin(10);
    nonPreemWcrtDlg->resize(600,400);
    nonPreemWcrtDlg->show();
    nonPreemWcrtDlg->setWindowTitle(QString("Non-Preempt WCRT Dialog"));
    QTextBrowser * nonPreemWcrtEdit = new QTextBrowser(nonPreemWcrtDlg);
    nonPreemWcrtEdit->setObjectName(QString::fromUtf8("nonPreemWcrtEdit"));
    layout->addWidget(nonPreemWcrtEdit);
    nonPreemWcrtDlg->setLayout(layout);
    nonPreemWcrtEdit->clear();
    QFont f( "Arial", 12, QFont::Bold);
    nonPreemWcrtEdit->setFont(f);
    nonPreemWcrt = non_proSched(taskWcet, taskPeriod, taskPriority);
    nonPreemWcrtEdit->append("      TaskName            :           WCRT        ");
    nonPreemWcrtEdit->autoFormatting();

    for(i = 0; i<taskNum; i++)
    {
        disPlay = QString("       ")+taskName[i]+QString("                         :             ")+ QString::number(nonPreemWcrt[i]);
        nonPreemWcrtEdit->append(disPlay);
    }


}

void MainWindow::on_actionPreemWcrt_triggered()
{
    int * PreemWcrt, i;
    QString disPlay;
    QDialog * PreemWcrtDlg = new QDialog(this);
    QHBoxLayout * layout = new QHBoxLayout(PreemWcrtDlg);
    layout->setMargin(10);
    PreemWcrtDlg->resize(600,400);
    PreemWcrtDlg->show();
    PreemWcrtDlg->setWindowTitle(QString("Preempt WCRT Dialog"));
    QTextBrowser * PreemWcrtEdit = new QTextBrowser(PreemWcrtDlg);
    PreemWcrtEdit->setObjectName(QString::fromUtf8("PreemWcrtEdit"));
    layout->addWidget(PreemWcrtEdit);
    PreemWcrtDlg->setLayout(layout);
    PreemWcrtEdit->clear();
    QFont f( "Arial", 12, QFont::Bold);
    PreemWcrtEdit->setFont(f);
    PreemWcrt = preSched(taskWcet, taskPeriod, taskDeadLine, taskPriority);
    PreemWcrtEdit->append("      TaskName            :           WCRT        ");
    PreemWcrtEdit->autoFormatting();

    for(i = 0; i<taskNum; i++)
    {
        disPlay = QString("       ")+taskName[i]+QString("                         :             ")+ QString::number(PreemWcrt[i]);
        PreemWcrtEdit->append(disPlay);
    }
}

void MainWindow::on_actionPreemWithThresWcrt_triggered()
{
    int * PreemWithThrWcrt, i;
    QString disPlay;
    QDialog * PreemWithThrWcrtDlg = new QDialog(this);
    QHBoxLayout * layout = new QHBoxLayout(PreemWithThrWcrtDlg);
    layout->setMargin(10);
    PreemWithThrWcrtDlg->resize(600,400);
    PreemWithThrWcrtDlg->show();
    PreemWithThrWcrtDlg->setWindowTitle(QString("Preempt With Threshold WCRT Dialog"));
    QTextBrowser * PreemWithThrWcrtEdit = new QTextBrowser(PreemWithThrWcrtDlg);
    PreemWithThrWcrtEdit->setObjectName(QString::fromUtf8("PreemWithThrWcrtEdit"));
    layout->addWidget(PreemWithThrWcrtEdit);
    PreemWithThrWcrtDlg->setLayout(layout);
    PreemWithThrWcrtEdit->clear();
    QFont f( "Arial", 12, QFont::Bold);
    PreemWithThrWcrtEdit->setFont(f);
    PreemWithThrWcrt = rePreSchedWithThres(taskWcet, taskPeriod, taskPriority, taskThreshold);
    PreemWithThrWcrtEdit->append("      TaskName            :           WCRT        ");
    PreemWithThrWcrtEdit->autoFormatting();

    for(i = 0; i<taskNum; i++)
    {
        disPlay = QString("       ")+taskName[i]+QString("                         :             ")+ QString::number(PreemWithThrWcrt[i]);
        PreemWithThrWcrtEdit->append(disPlay);
    }
}

