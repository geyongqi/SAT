#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <ctype.h>
#include <string.h>
#include <dirent.h>
#include <stdlib.h>
#include <sched.h>
#include <errno.h>

#define MAXTASKNUM  10          /* Maximum Number of Tasks, Cooperate with TASKNUM */

/* Include C header */
extern "C"{
#include "Threshold.h"
}

namespace Ui {
    class MainWindow;
}

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    MainWindow(QWidget *parent = 0);
    ~MainWindow();
    QString printTaskInfo(QString taskName, DIR *dir);
    void sched_set_threshold(pid_t pid, unsigned int rt_threshold);
    void sched_get_threshold(pid_t pid, unsigned int *rt_threshold);

protected:
    void changeEvent(QEvent *e);

private:
    Ui::MainWindow *ui;
    /* Task's Attributions */
    QString taskName[MAXTASKNUM];
    int taskPeriod[MAXTASKNUM];
    int taskPriority[MAXTASKNUM];
    int taskWcrt[MAXTASKNUM];
    int taskWcet[MAXTASKNUM];
    int taskDeadLine[MAXTASKNUM];
    int taskThreshold[MAXTASKNUM];
    int taskFlag;

    int monitorFlag ;
    /* Scheduling Attributions */
    pid_t ppid;
    struct sched_param  pparam;
    unsigned int p_rt_threshold;

private slots:
    void on_actionPreemWithThresWcrt_triggered();
    void on_actionPreemWcrt_triggered();
    void on_actionNonPreemWcrt_triggered();
    void on_taskRunningBtn_clicked();
    void on_taskStartBtn_clicked();
    void on_actionCreator_triggered();
    void on_actionVersion_triggered();
    void on_compThrBtn_clicked();
    void on_addTaskBtn_clicked();
};

#endif // END MAINWINDOW_H
