/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created: Mon Sep 23 20:52:03 2013
**      by: Qt User Interface Compiler version 4.6.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QFrame>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QMainWindow>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QPushButton>
#include <QtGui/QStatusBar>
#include <QtGui/QTextBrowser>
#include <QtGui/QToolBar>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionExit;
    QAction *actionVersion;
    QAction *actionContents;
    QAction *actionCreator;
    QAction *actionNonPreemWcrt;
    QAction *actionPreemWcrt;
    QAction *actionPreemWithThresWcrt;
    QWidget *centralWidget;
    QFrame *line;
    QPushButton *addTaskBtn;
    QTextBrowser *taskList;
    QPushButton *compThrBtn;
    QTextBrowser *taskThreshold;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QLabel *TaskName;
    QLabel *period;
    QLabel *priority;
    QLabel *WCET;
    QLabel *DeadLine;
    QWidget *layoutWidget1;
    QVBoxLayout *verticalLayout_2;
    QLineEdit *taskNameEdit;
    QLineEdit *periodEdit;
    QLineEdit *priorityEdit;
    QLineEdit *wcetEdit;
    QLineEdit *deadLineEdit;
    QLabel *TaskName_2;
    QLabel *TaskName_3;
    QLabel *TaskName_4;
    QLabel *taskMonitor;
    QFrame *line_2;
    QLabel *taskMonitor_2;
    QPushButton *taskStartBtn;
    QTextBrowser *taskRunningStatics;
    QLabel *monitorTaskLabel;
    QLineEdit *monitorTaskEdit;
    QPushButton *taskRunningBtn;
    QTextBrowser *taskRunningEdit;
    QMenuBar *menuBar;
    QMenu *menuFile_F;
    QMenu *menuWCET_E;
    QMenu *menuWCRT_R;
    QMenu *menuTHRESHOLD_T;
    QMenu *menuCONTEXT_SWITCH_S;
    QMenu *menuHELP_H;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1053, 712);
        actionExit = new QAction(MainWindow);
        actionExit->setObjectName(QString::fromUtf8("actionExit"));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/File/Resource/exit.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionExit->setIcon(icon);
        actionVersion = new QAction(MainWindow);
        actionVersion->setObjectName(QString::fromUtf8("actionVersion"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/File/Resource/none.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionVersion->setIcon(icon1);
        actionContents = new QAction(MainWindow);
        actionContents->setObjectName(QString::fromUtf8("actionContents"));
        actionCreator = new QAction(MainWindow);
        actionCreator->setObjectName(QString::fromUtf8("actionCreator"));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/File/Resource/EU.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionCreator->setIcon(icon2);
        actionNonPreemWcrt = new QAction(MainWindow);
        actionNonPreemWcrt->setObjectName(QString::fromUtf8("actionNonPreemWcrt"));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/File/Resource/CC.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionNonPreemWcrt->setIcon(icon3);
        actionPreemWcrt = new QAction(MainWindow);
        actionPreemWcrt->setObjectName(QString::fromUtf8("actionPreemWcrt"));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/File/Resource/RC.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionPreemWcrt->setIcon(icon4);
        actionPreemWithThresWcrt = new QAction(MainWindow);
        actionPreemWithThresWcrt->setObjectName(QString::fromUtf8("actionPreemWithThresWcrt"));
        QIcon icon5;
        icon5.addFile(QString::fromUtf8(":/File/Resource/TC.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionPreemWithThresWcrt->setIcon(icon5);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        line = new QFrame(centralWidget);
        line->setObjectName(QString::fromUtf8("line"));
        line->setGeometry(QRect(0, 240, 1061, 31));
        QFont font;
        font.setFamily(QString::fromUtf8("Bitstream Charter"));
        line->setFont(font);
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);
        addTaskBtn = new QPushButton(centralWidget);
        addTaskBtn->setObjectName(QString::fromUtf8("addTaskBtn"));
        addTaskBtn->setGeometry(QRect(280, 120, 111, 41));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Bitstream Charter"));
        font1.setPointSize(12);
        addTaskBtn->setFont(font1);
        taskList = new QTextBrowser(centralWidget);
        taskList->setObjectName(QString::fromUtf8("taskList"));
        taskList->setGeometry(QRect(420, 50, 261, 192));
        compThrBtn = new QPushButton(centralWidget);
        compThrBtn->setObjectName(QString::fromUtf8("compThrBtn"));
        compThrBtn->setGeometry(QRect(710, 120, 171, 41));
        compThrBtn->setFont(font1);
        taskThreshold = new QTextBrowser(centralWidget);
        taskThreshold->setObjectName(QString::fromUtf8("taskThreshold"));
        taskThreshold->setGeometry(QRect(910, 50, 111, 192));
        layoutWidget = new QWidget(centralWidget);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(30, 50, 90, 191));
        layoutWidget->setFont(font);
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        TaskName = new QLabel(layoutWidget);
        TaskName->setObjectName(QString::fromUtf8("TaskName"));
        QFont font2;
        font2.setFamily(QString::fromUtf8("Bitstream Charter"));
        font2.setPointSize(12);
        font2.setBold(false);
        font2.setWeight(50);
        TaskName->setFont(font2);

        verticalLayout->addWidget(TaskName);

        period = new QLabel(layoutWidget);
        period->setObjectName(QString::fromUtf8("period"));
        period->setFont(font2);
        period->setTextFormat(Qt::PlainText);
        period->setAlignment(Qt::AlignJustify|Qt::AlignVCenter);
        period->setWordWrap(false);
        period->setMargin(0);
        period->setIndent(0);

        verticalLayout->addWidget(period);

        priority = new QLabel(layoutWidget);
        priority->setObjectName(QString::fromUtf8("priority"));
        priority->setFont(font2);

        verticalLayout->addWidget(priority);

        WCET = new QLabel(layoutWidget);
        WCET->setObjectName(QString::fromUtf8("WCET"));
        WCET->setFont(font2);

        verticalLayout->addWidget(WCET);

        DeadLine = new QLabel(layoutWidget);
        DeadLine->setObjectName(QString::fromUtf8("DeadLine"));
        DeadLine->setFont(font2);

        verticalLayout->addWidget(DeadLine);

        layoutWidget1 = new QWidget(centralWidget);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(120, 50, 131, 194));
        verticalLayout_2 = new QVBoxLayout(layoutWidget1);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        taskNameEdit = new QLineEdit(layoutWidget1);
        taskNameEdit->setObjectName(QString::fromUtf8("taskNameEdit"));

        verticalLayout_2->addWidget(taskNameEdit);

        periodEdit = new QLineEdit(layoutWidget1);
        periodEdit->setObjectName(QString::fromUtf8("periodEdit"));

        verticalLayout_2->addWidget(periodEdit);

        priorityEdit = new QLineEdit(layoutWidget1);
        priorityEdit->setObjectName(QString::fromUtf8("priorityEdit"));

        verticalLayout_2->addWidget(priorityEdit);

        wcetEdit = new QLineEdit(layoutWidget1);
        wcetEdit->setObjectName(QString::fromUtf8("wcetEdit"));

        verticalLayout_2->addWidget(wcetEdit);

        deadLineEdit = new QLineEdit(layoutWidget1);
        deadLineEdit->setObjectName(QString::fromUtf8("deadLineEdit"));

        verticalLayout_2->addWidget(deadLineEdit);

        TaskName_2 = new QLabel(centralWidget);
        TaskName_2->setObjectName(QString::fromUtf8("TaskName_2"));
        TaskName_2->setGeometry(QRect(80, 20, 131, 27));
        QFont font3;
        font3.setFamily(QString::fromUtf8("Bitstream Charter"));
        font3.setPointSize(14);
        font3.setBold(true);
        font3.setWeight(75);
        TaskName_2->setFont(font3);
        TaskName_3 = new QLabel(centralWidget);
        TaskName_3->setObjectName(QString::fromUtf8("TaskName_3"));
        TaskName_3->setGeometry(QRect(520, 20, 81, 27));
        TaskName_3->setFont(font3);
        TaskName_4 = new QLabel(centralWidget);
        TaskName_4->setObjectName(QString::fromUtf8("TaskName_4"));
        TaskName_4->setGeometry(QRect(920, 20, 91, 27));
        TaskName_4->setFont(font3);
        taskMonitor = new QLabel(centralWidget);
        taskMonitor->setObjectName(QString::fromUtf8("taskMonitor"));
        taskMonitor->setGeometry(QRect(200, 260, 161, 20));
        taskMonitor->setFont(font3);
        line_2 = new QFrame(centralWidget);
        line_2->setObjectName(QString::fromUtf8("line_2"));
        line_2->setGeometry(QRect(520, 260, 20, 391));
        line_2->setFrameShape(QFrame::VLine);
        line_2->setFrameShadow(QFrame::Sunken);
        taskMonitor_2 = new QLabel(centralWidget);
        taskMonitor_2->setObjectName(QString::fromUtf8("taskMonitor_2"));
        taskMonitor_2->setGeometry(QRect(730, 270, 151, 20));
        taskMonitor_2->setFont(font3);
        taskStartBtn = new QPushButton(centralWidget);
        taskStartBtn->setObjectName(QString::fromUtf8("taskStartBtn"));
        taskStartBtn->setGeometry(QRect(380, 300, 111, 41));
        taskStartBtn->setFont(font1);
        taskRunningStatics = new QTextBrowser(centralWidget);
        taskRunningStatics->setObjectName(QString::fromUtf8("taskRunningStatics"));
        taskRunningStatics->setGeometry(QRect(30, 350, 471, 291));
        monitorTaskLabel = new QLabel(centralWidget);
        monitorTaskLabel->setObjectName(QString::fromUtf8("monitorTaskLabel"));
        monitorTaskLabel->setGeometry(QRect(30, 310, 81, 21));
        QFont font4;
        font4.setFamily(QString::fromUtf8("Bitstream Charter"));
        font4.setPointSize(12);
        font4.setBold(true);
        font4.setWeight(75);
        monitorTaskLabel->setFont(font4);
        monitorTaskEdit = new QLineEdit(centralWidget);
        monitorTaskEdit->setObjectName(QString::fromUtf8("monitorTaskEdit"));
        monitorTaskEdit->setGeometry(QRect(130, 306, 113, 31));
        taskRunningBtn = new QPushButton(centralWidget);
        taskRunningBtn->setObjectName(QString::fromUtf8("taskRunningBtn"));
        taskRunningBtn->setGeometry(QRect(900, 300, 111, 41));
        taskRunningBtn->setFont(font1);
        taskRunningEdit = new QTextBrowser(centralWidget);
        taskRunningEdit->setObjectName(QString::fromUtf8("taskRunningEdit"));
        taskRunningEdit->setGeometry(QRect(560, 350, 461, 281));
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1053, 22));
        menuFile_F = new QMenu(menuBar);
        menuFile_F->setObjectName(QString::fromUtf8("menuFile_F"));
        menuWCET_E = new QMenu(menuBar);
        menuWCET_E->setObjectName(QString::fromUtf8("menuWCET_E"));
        menuWCRT_R = new QMenu(menuBar);
        menuWCRT_R->setObjectName(QString::fromUtf8("menuWCRT_R"));
        menuTHRESHOLD_T = new QMenu(menuBar);
        menuTHRESHOLD_T->setObjectName(QString::fromUtf8("menuTHRESHOLD_T"));
        menuCONTEXT_SWITCH_S = new QMenu(menuBar);
        menuCONTEXT_SWITCH_S->setObjectName(QString::fromUtf8("menuCONTEXT_SWITCH_S"));
        menuHELP_H = new QMenu(menuBar);
        menuHELP_H->setObjectName(QString::fromUtf8("menuHELP_H"));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        menuBar->addAction(menuFile_F->menuAction());
        menuBar->addAction(menuWCET_E->menuAction());
        menuBar->addAction(menuWCRT_R->menuAction());
        menuBar->addAction(menuTHRESHOLD_T->menuAction());
        menuBar->addAction(menuCONTEXT_SWITCH_S->menuAction());
        menuBar->addAction(menuHELP_H->menuAction());
        menuFile_F->addAction(actionExit);
        menuWCET_E->addSeparator();
        menuWCET_E->addAction(actionNonPreemWcrt);
        menuWCRT_R->addSeparator();
        menuWCRT_R->addAction(actionPreemWcrt);
        menuTHRESHOLD_T->addSeparator();
        menuTHRESHOLD_T->addAction(actionPreemWithThresWcrt);
        menuHELP_H->addAction(actionVersion);
        menuHELP_H->addAction(actionContents);
        menuHELP_H->addAction(actionCreator);
        mainToolBar->addAction(actionExit);
        mainToolBar->addSeparator();
        mainToolBar->addAction(actionNonPreemWcrt);
        mainToolBar->addSeparator();
        mainToolBar->addAction(actionPreemWcrt);
        mainToolBar->addSeparator();
        mainToolBar->addAction(actionPreemWithThresWcrt);
        mainToolBar->addSeparator();
        mainToolBar->addAction(actionVersion);
        mainToolBar->addSeparator();
        mainToolBar->addAction(actionCreator);

        retranslateUi(MainWindow);
        QObject::connect(actionExit, SIGNAL(triggered()), MainWindow, SLOT(close()));

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0, QApplication::UnicodeUTF8));
        actionExit->setText(QApplication::translate("MainWindow", "Exit", 0, QApplication::UnicodeUTF8));
        actionVersion->setText(QApplication::translate("MainWindow", "Version", 0, QApplication::UnicodeUTF8));
        actionContents->setText(QApplication::translate("MainWindow", "Contents", 0, QApplication::UnicodeUTF8));
        actionCreator->setText(QApplication::translate("MainWindow", "Creator", 0, QApplication::UnicodeUTF8));
        actionNonPreemWcrt->setText(QApplication::translate("MainWindow", "NonPreemWcrt", 0, QApplication::UnicodeUTF8));
        actionPreemWcrt->setText(QApplication::translate("MainWindow", "PreemWcrt", 0, QApplication::UnicodeUTF8));
        actionPreemWithThresWcrt->setText(QApplication::translate("MainWindow", "PreemWithThresWcrt", 0, QApplication::UnicodeUTF8));
        addTaskBtn->setText(QApplication::translate("MainWindow", "Add Task=>", 0, QApplication::UnicodeUTF8));
        compThrBtn->setText(QApplication::translate("MainWindow", "Compute Threshold=>", 0, QApplication::UnicodeUTF8));
        TaskName->setText(QApplication::translate("MainWindow", "Task Name:", 0, QApplication::UnicodeUTF8));
        period->setText(QApplication::translate("MainWindow", "Period:", 0, QApplication::UnicodeUTF8));
        priority->setText(QApplication::translate("MainWindow", "Priority:", 0, QApplication::UnicodeUTF8));
        WCET->setText(QApplication::translate("MainWindow", "WCET:", 0, QApplication::UnicodeUTF8));
        DeadLine->setText(QApplication::translate("MainWindow", "DeadLine:", 0, QApplication::UnicodeUTF8));
        TaskName_2->setText(QApplication::translate("MainWindow", "Task Attributes", 0, QApplication::UnicodeUTF8));
        TaskName_3->setText(QApplication::translate("MainWindow", "Task List", 0, QApplication::UnicodeUTF8));
        TaskName_4->setText(QApplication::translate("MainWindow", "Threshold", 0, QApplication::UnicodeUTF8));
        taskMonitor->setText(QApplication::translate("MainWindow", "TaskStatisticsInfo", 0, QApplication::UnicodeUTF8));
        taskMonitor_2->setText(QApplication::translate("MainWindow", "TaskRunningInfo", 0, QApplication::UnicodeUTF8));
        taskStartBtn->setText(QApplication::translate("MainWindow", "START", 0, QApplication::UnicodeUTF8));
        monitorTaskLabel->setText(QApplication::translate("MainWindow", "TaskName:", 0, QApplication::UnicodeUTF8));
        taskRunningBtn->setText(QApplication::translate("MainWindow", "RUN", 0, QApplication::UnicodeUTF8));
        menuFile_F->setTitle(QApplication::translate("MainWindow", "File(&F)", 0, QApplication::UnicodeUTF8));
        menuWCET_E->setTitle(QApplication::translate("MainWindow", "Non-Preemption(&N)", 0, QApplication::UnicodeUTF8));
        menuWCRT_R->setTitle(QApplication::translate("MainWindow", "Preemption(&P)", 0, QApplication::UnicodeUTF8));
        menuTHRESHOLD_T->setTitle(QApplication::translate("MainWindow", "PreemptWithThreshold(&T)", 0, QApplication::UnicodeUTF8));
        menuCONTEXT_SWITCH_S->setTitle(QApplication::translate("MainWindow", "CONTEXT SWITCH(&S)", 0, QApplication::UnicodeUTF8));
        menuHELP_H->setTitle(QApplication::translate("MainWindow", "HELP(&H)", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
